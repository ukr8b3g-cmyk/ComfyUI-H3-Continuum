# Continuum用LLMシステムプロンプト

1. `SYSTEM_PROMPT.txt` の本文をLLMアプリのシステムプロンプト欄へ貼ります。
2. 必要に応じて `knowledge` の関連資料を会話・資料コンテキストへ渡します。ファイル名やパスを書くだけでは自動読込されません。
3. 通常のユーザーメッセージで映像内容、実際のChunksとSeconds per Chunk、接続入力、台詞・歌詞を指定します。

例:「I2VA、Chunks=3、Seconds per Chunk=15、45秒のノーカット。添付画像から動作を継続。カメラ固定。Timelineで作成してください。」

出力された設定メモはノードへ貼りません。Sequence Promptのコードブロック内だけを使用し、Prompt Formatと実行設定は実際のノード側で合わせてください。プロンプトはノード設定を変更しません。

`knowledge/continuum-contract.md` は割り当て規則、`h3-and-audio.md` は画像・音声参照、`continuity.md` は長尺・延長、`examples.md` は例です。

英語システムプロンプト＋詳細資料の構成です。台詞・歌詞は指定言語の原文を保持します。V3.8の固定コミットを基準にした独自適応版であり、MiniMax公式システムプロンプトではありません。特定LLMでの出力品質や動画生成品質は未検証です。
