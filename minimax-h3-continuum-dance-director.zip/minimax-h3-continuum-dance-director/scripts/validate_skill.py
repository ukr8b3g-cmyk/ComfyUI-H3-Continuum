#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]

REQUIRED = [
    "SKILL.md",
    "README.md",
    "README_JA.md",
    "NOTICE.md",
    "agents/openai.yaml",
    "references/selection-options.md",
    "references/choreography-continuity.md",
    "references/continuum-timeline-contract.md",
    "references/camera-audio.md",
    "references/dance-language.md",
    "references/quality-guardrails.md",
    "examples/3x5s.md",
    "examples/6x10s.md",
]

errors = []

for rel in REQUIRED:
    path = ROOT / rel
    if not path.is_file():
        errors.append(f"missing: {rel}")

skill = (ROOT / "SKILL.md").read_text(encoding="utf-8") if (ROOT / "SKILL.md").exists() else ""

if not skill.startswith("---\n"):
    errors.append("SKILL.md: missing YAML frontmatter start")

if "name: minimax-h3-continuum-dance-director" not in skill:
    errors.append("SKILL.md: unexpected or missing skill name")

# Timeline header guard: flag examples where prose is placed on the same
# line after a [0-5s]-style time range.
bad_header = re.compile(r"^\[\d+(?:\.\d+)?-\d+(?:\.\d+)?s\][ \t]+\S", re.MULTILINE)
for path in (ROOT / "examples").glob("*.md"):
    text = path.read_text(encoding="utf-8")
    for match in bad_header.finditer(text):
        errors.append(f"{path.relative_to(ROOT)}: Timeline header has same-line prose: {match.group(0)!r}")

# Local-reference guard.
for ref in re.findall(r"`(references/[^`]+\.md)`", skill):
    if not (ROOT / ref).is_file():
        errors.append(f"SKILL.md: missing referenced file {ref}")

if errors:
    print("VALIDATION FAILED")
    for e in errors:
        print(f"- {e}")
    sys.exit(1)

print("VALIDATION PASS")
print(f"Skill root: {ROOT}")
print(f"Required files: {len(REQUIRED)}/{len(REQUIRED)}")
