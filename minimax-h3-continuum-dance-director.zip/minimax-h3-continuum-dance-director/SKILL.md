---
name: minimax-h3-continuum-dance-director
description: Create long-form single-dancer MiniMax H3 choreography prompts specifically for ComfyUI-H3-Continuum. Build a chunk-aware dance plan, preserve body momentum and camera motion across boundaries, and output a copy-ready Continuum Timeline Sequence Prompt plus minimal sampler settings. Use for one primary dancer and long-form H3 dance sequences; do not use for group choreography or for changing Continuum sampling code.
---

# MiniMax H3 Continuum Dance Director

Create a long-form single-dancer choreography plan for MiniMax H3 Continuum.

This skill is dance-specialized. Its job is not to generate video, modify ComfyUI nodes, or solve latent/image-quality drift. Its job is to produce a **chunk-aware Continuum Timeline prompt** whose dance motion, body state, camera state, identity, environment, and audio intent carry naturally from one chunk to the next.

## Required reading

Before generating the final output, read these references:

1. `references/selection-options.md`
2. `references/choreography-continuity.md`
3. `references/continuum-timeline-contract.md`
4. `references/camera-audio.md`
5. `references/dance-language.md`
6. `references/quality-guardrails.md`

## Core workflow

1. Inspect the user's supplied dancer image when available. If the user explicitly wants image-to-video and no image is accessible, ask for the image. Do not invent unseen clothing, anatomy, props, text, or background details.
2. Keep exactly one **primary choreographed dancer**. Passive background people may exist only if already present or explicitly requested, but they must not become backup dancers, clones, independently choreographed reflections, or duplicated bodies.
3. Resolve the configuration. If the user already supplied enough information, do not show a redundant wizard. Otherwise show all unresolved choices together.
4. Determine:
   - dance style
   - total duration
   - chunk duration
   - performance tone
   - camera behavior
   - audio behavior
   - ending behavior
   - continuity strength
5. Derive the number of chunks. Prefer an integer `total_duration / chunk_seconds`. If the requested duration is not divisible by the chunk duration, preserve the user's duration by planning the final partial interval and recommend Continuum `exact_total_duration` when appropriate.
6. Build one **Global Dance Spine** before writing individual chunks:
   - opening body state
   - progression of energy
   - major movement families
   - spatial travel
   - camera arc
   - climax
   - ending or loop return
7. Allocate a motion budget per chunk. Do not overload short chunks.
8. For every chunk, internally track:
   - `start_state`
   - `core_movements`
   - `transition_logic`
   - `end_state`
   - `residual_momentum`
   - `camera_state`
   - `audio_state`
9. For Chunk 2 and later, make the opening action explicitly continue the exact physical and cinematic state established at the prior boundary. Never start a new neutral pose unless the choreography intentionally arrives at neutral at the preceding boundary.
10. Validate the Timeline syntax and continuity rules.
11. Return:
   - a compact `Continuum Settings` block
   - a copy-ready `Sequence Prompt` using Continuum Timeline headers
   - optionally a short `Continuity Notes` block only when useful for troubleshooting or iteration

If the user asks for prompt-only output, return only the Timeline Sequence Prompt.

## Default assumptions

Use these only when the user has not specified otherwise:

- primary dancer: one
- chunk duration: `5s` for conservative first tests; `10s` when the user explicitly targets longer dance chunks
- continuity strength: `natural`
- camera: `dance_follow`
- audio: `preserve_or_none` depending on supplied media
- ending: `resolved_pose`
- Continuum Prompt Format: `Auto` with valid Timeline syntax
- Continuum continuity profile: recommend `Balanced - 22 frames` as the neutral starting point, but do not imply that this prompt skill controls the sampler internally

Do not silently override a user-selected Continuum setting.

## Motion-budget policy

Use these default per-chunk budgets:

| Chunk duration | Core movement budget |
| --- | --- |
| 4-5s | 2-4 |
| 6s | 3-4 |
| 7-10s | 4-6 |
| 11-15s | 5-8 |

A "core movement" is a readable movement phrase, not every limb adjustment.

Prefer fewer complete actions with visible transfer of weight over many disconnected named moves.

## Boundary rule

Every boundary must pass forward a usable handoff state.

The previous chunk should end with concrete physical information such as:

- supporting leg / foot placement
- weight distribution
- torso orientation
- shoulder or hip rotation
- arm line
- head/gaze direction
- vertical level
- travel direction
- remaining angular or linear momentum
- camera position and motion

The next chunk must consume that state rather than repeating it as a static description.

Think:

`landing state -> residual momentum -> next initiation`

not:

`pose A -> reset -> pose B`.

## Global invariants

Across all chunks, preserve unless the user explicitly requests a change:

- dancer identity
- face and body proportions
- limb count and anatomy
- clothing and accessories
- props
- scene identity
- lighting logic
- visible text
- music/voice continuity
- direction of established motion at the chunk boundary

Do not use vague phrases such as "same as before" as the only continuity mechanism. State the most important inherited physical condition explicitly.

## Dance-specific priorities

Prioritize, in this order:

1. readable body mechanics
2. continuity across chunk boundaries
3. rhythm/energy progression
4. full-body visibility when the movement requires it
5. camera choreography
6. flourish and style vocabulary

For kicks, jumps, floorwork, wide extensions, backbends, traveling turns, or large arm lines, keep enough of the body in frame to make the movement readable.

## Camera rule

The camera participates in the choreography but does not fight it.

When a chunk ends during a tracking, orbiting, pushing, pulling, craning, tilting, or handheld movement, the next chunk should continue from that camera state and only then redirect naturally.

Avoid unexplained boundary cuts, sudden axis flips, unexplained focal-length jumps, and "camera reset to front."

## Audio rule

Never invent precise BPM, beat drops, chorus locations, lyric timing, instrumentation, or exact musical events that the user did not provide and that cannot be inspected.

When reference/performance audio is intended to remain unchanged, describe visual synchronization without rewriting or altering the audio. Preserve supplied lyrics/dialogue verbatim when the user provides them.

## Continuum boundary

This skill writes prompts for Continuum; it does **not**:

- change Continuum sampler code
- alter native AV latent continuation
- claim to repair long-form contrast/saturation/sharpness drift
- replace seam-correction logic
- change Spectrum/Sage/Sol behavior
- guarantee physical continuity that the model fails to render

Treat prompt continuity and latent/image-quality continuity as separate layers.

## Output contract

Default output:

### Continuum Settings
- `chunks: N`
- `chunk_seconds: X`
- `Prompt Format: Auto (Timeline)`
- `continuity: <recommended or user-specified>`
- `audio_continuity: <On/Off/unchanged>`
- `exact_total_duration: <value only when relevant>`

### Sequence Prompt

Use exact Timeline formatting:

`[0-5s]`
on its own line, followed by prompt text on later line(s).

Never write:

`[0-5s] prompt text...`

because the text on the same line can prevent Timeline-header recognition.

Each section must be a self-contained continuation instruction for its time range while remaining part of one global dance.

## Final self-check

Before returning the prompt, verify:

- one primary dancer only
- total time is correct
- all Timeline headers are on their own lines
- Timeline ranges are ordered and non-overlapping
- motion density fits chunk length
- Chunk 2+ inherit previous body state
- Chunk 2+ inherit or intentionally redirect previous camera state
- no accidental neutral-body reset
- no unexplained scene/costume/identity change
- no fabricated audio facts
- final chunk fulfills the selected ending
- loop ending, when selected, returns toward a state that can plausibly reconnect to the opening
