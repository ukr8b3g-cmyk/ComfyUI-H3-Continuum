# MiniMax H3 Continuum Dance Director Skill

A dance-specialized Agent Skill for writing long-form single-dancer MiniMax H3 prompts for ComfyUI-H3-Continuum.

It plans one global routine, divides it into Continuum chunks, carries body momentum and camera motion across every boundary, and emits a copy-ready Timeline Sequence Prompt.

## Invoke

```text
$minimax-h3-continuum-dance-director
```

## Core features

- Single-dancer long-form choreography
- Continuum Timeline output
- Chunk-aware motion budgets
- Body-state handoff across chunk boundaries
- Momentum-aware transitions
- Camera-state handoff
- Audio hallucination safeguards
- Loop, resolved-pose, soft-release, and impact endings
- Prompt-only mode when requested

## Package layout

```text
minimax-h3-continuum-dance-director/
├── SKILL.md
├── README.md
├── README_JA.md
├── NOTICE.md
├── agents/
│   └── openai.yaml
├── references/
│   ├── selection-options.md
│   ├── choreography-continuity.md
│   ├── continuum-timeline-contract.md
│   ├── camera-audio.md
│   ├── dance-language.md
│   └── quality-guardrails.md
├── examples/
│   ├── 3x5s.md
│   └── 6x10s.md
└── scripts/
    └── validate_skill.py
```

## Scope

This skill writes prompts. It does not modify ComfyUI-H3-Continuum, MiniMax H3, or sampler behavior.
