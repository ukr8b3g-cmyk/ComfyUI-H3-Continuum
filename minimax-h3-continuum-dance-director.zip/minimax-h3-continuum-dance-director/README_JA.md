# MiniMax H3 Continuum Dance Director Skill

MiniMax H3 + ComfyUI-H3-Continuum向けの、**1人ダンサー専用・長尺ダンスPrompt Skill**です。

通常の「ダンス動画プロンプト」を作るのではなく、ContinuumのChunk構造に合わせて、

- 長尺全体の振付を先に設計
- ChunkごとのMotion Budgetを決定
- 前Chunkの着地・重心・向き・残留モーションを次Chunkへ継承
- カメラ位置と移動方向もChunk間で継承
- Continuumで認識できるTimeline形式へ変換

を行います。

## 呼び出し

```text
$minimax-h3-continuum-dance-director
```

例：

```text
$minimax-h3-continuum-dance-director
この画像の人物で、60秒、10秒×6チャンク。
K-pop寄りの力強いダンス。カメラは動的追従。
最後はヒーローポーズ。音声は参照音声を維持。
```

情報が足りない場合は、必要な項目だけを一度に提示します。

## 主な入力

- Dance Style
- Total Duration
- Chunk Duration
- Performance Tone
- Camera
- Audio
- Ending
- Continuity Strength

## 出力

基本は2つです。

1. **Continuum Settings**
2. **Sequence Prompt (Timeline)**

例：

```text
[0-5s]
...

[5-10s]
Continue directly from the preceding landing...
```

ContinuumではTimelineヘッダーを必ず単独行にします。

## Continuum特化ポイント

このSkillでは各Chunkに対して内部的に次の状態を持ちます。

```text
start_state
core_movements
transition_logic
end_state
residual_momentum
camera_state
audio_state
```

たとえばChunk 1が「右脚支持・上体左向き・時計回りの回転が残った状態」で終わった場合、Chunk 2を正面ニュートラルから始めず、その回転と重心を利用して次の動作へ接続します。

## Motion Budget

目安：

| Chunk | Core movements |
| --- | ---: |
| 4-5秒 | 2-4 |
| 6秒 | 3-4 |
| 7-10秒 | 4-6 |
| 11-15秒 | 5-8 |

短いChunkに動作を詰め込みすぎず、1つ1つの重心移動と着地を明確にする方針です。

## 対象

向いている用途：

- MiniMax H3
- ComfyUI-H3-Continuum
- 1人ダンサー
- 10秒以上の長尺ダンス
- 複数Chunk間の振付・カメラ連続性

対象外：

- グループダンスの隊形制御
- Continuum本体のコード変更
- Issue #13のような画質driftそのものの修正
- 動画生成そのもの

## 参考設計

このSkillは、MiniMax H3のsingle-dancer prompt設計から「重心・動量・身体の連続性」という考え方を参考にしつつ、ComfyUI-H3-ContinuumのTimeline / multi-chunk運用向けに独立して再設計したものです。元リポジトリの文章やファイルを再配布するものではありません。
