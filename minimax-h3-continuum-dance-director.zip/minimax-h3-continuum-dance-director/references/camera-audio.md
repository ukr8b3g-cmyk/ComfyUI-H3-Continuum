# Camera and Audio

## Camera as a choreography partner

Camera motion must improve movement readability.

### Full-body priority

Use wider framing for:

- jumps
- kicks
- floorwork
- leg extensions
- backbends
- traveling phrases
- large arm geometry
- turns where footwork matters

### Detail priority

Use medium or closer framing for:

- facial expression
- eye contact
- hand detail
- shoulder isolation
- compact upper-body popping/locking details

Do not crop away information necessary to understand the motion.

## Camera handoff state

At chunk boundaries track, when relevant:

- camera-left / camera-right / frontal / rear-quarter position
- distance
- height
- direction of orbit
- push-in / pull-out velocity
- lateral tracking direction
- tilt or crane direction
- handheld energy

If the previous chunk ends mid-orbit, continue that orbit into the next chunk before redirecting.

Avoid a boundary pattern where every chunk restarts from a centered frontal medium shot.

## One-take mode

Maintain plausible continuous camera travel.

Cuts are disallowed unless the user explicitly permits them.

Use acceleration and deceleration rather than instant camera repositioning.

## Impact camera

Impact does not mean constant shake.

Use short camera accents around selected movement peaks while preserving body readability.

## Audio safety

Never fabricate:

- BPM
- beat numbers
- drop timestamps
- chorus timestamps
- instrumentation
- lyric words
- melody
- exact phrase boundaries

unless supplied or inspectable.

When the user supplies reference audio but exact structure cannot be analyzed, use relative language:

- as the next musical phrase begins
- with the next clear accent
- through the sustained vocal line
- as the phrase resolves

Do not claim a precise event at a precise second without evidence.

## Preserve-reference behavior

When the user's intent is to keep reference/performance audio:

- keep the audio unchanged
- synchronize choreography visually to it
- do not rewrite lyrics
- do not add new vocals
- do not claim that prompt wording changes the source mix

If audio continuity is desired across Continuum chunks, recommend the relevant Continuum audio-continuity setting, but keep that sampler setting separate from the prose choreography.
