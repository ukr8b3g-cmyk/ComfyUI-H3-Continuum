# Dance Language

Use vocabulary as a movement grammar, not as a checklist of named moves.

## Hip-hop / Urban

Emphasize:

- grounded weight
- groove
- rebounds
- directional steps
- torso accents
- dynamic level changes
- controlled freezes

Avoid making every phrase acrobatic.

## Popping

Emphasize:

- hits
- isolations
- waves
- tutting/angle vocabulary when requested
- contraction/release
- precise stop-and-go timing

Maintain readable joint pathways and avoid impossible locking of the whole body.

## Locking

Emphasize:

- clear locks
- points
- wrist rolls
- bounce
- playful directional changes
- readable pauses

## House

Emphasize:

- fast footwork
- loose upper body
- jacking
- traveling floor patterns
- flowing weight transfer

Keep feet visible when the footwork is the point.

## Waacking

Emphasize:

- arm rotations
- overhead pathways
- pose accents
- shoulder rhythm
- expressive gaze
- fast but traceable arm arcs

## Voguing

Emphasize:

- angular lines
- hand performance
- catwalk elements
- controlled poses
- framing of face/body geometry

Do not force floorwork or dips unless appropriate.

## K-pop

Emphasize:

- clean phrase structure
- iconic upper-body accents
- synchronized-looking internal timing even with one dancer
- dynamic changes between full-body and expression shots
- polished final shapes

## Jazz

Emphasize:

- lines
- turns
- directional kicks
- isolations
- expressive torso
- clear finishing shapes

## Contemporary

Emphasize:

- breath-like expansion/contraction
- off-axis balance
- floor transitions
- suspension and release
- continuous momentum

Make low-to-high transitions physically readable.

## Ballet

Emphasize:

- turnout-aware line
- controlled extensions
- balance
- turns
- soft but precise landings
- posture and arm coordination

Avoid excessive technical claims if the requested choreography is only ballet-inspired.

## Chinese classical dance

Emphasize:

- circular pathways
- sleeve/arm flow when clothing supports it
- torso spirals
- controlled gaze
- elegant weight shifts
- sustained line and direction

Do not invent cultural props or costume elements not present or requested.

## Latin

Emphasize the requested form if specified. Otherwise use broad Latin-inspired body rhythm cautiously.

Focus on:

- hip action
- grounded steps
- torso/shoulder relationship
- directional turns
- rhythmic weight transfer

## Sensual flow

Emphasize:

- controlled torso waves
- hip articulation
- slow-to-fast contrast
- sustained gaze
- smooth weight transfer

Keep wording performance-oriented rather than sexualized when the user did not request sexual content.
