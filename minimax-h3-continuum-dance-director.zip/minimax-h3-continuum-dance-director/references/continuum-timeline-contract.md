# Continuum Timeline Contract

This skill targets ComfyUI-H3-Continuum's Sequence Prompt Timeline mode.

## Header syntax

A Timeline header must be on its own line.

Correct:

```text
[0-5s]
The dancer begins...
```

Incorrect:

```text
[0-5s] The dancer begins...
```

Do not place prompt content after the header on the same line.

## Range construction

For fixed chunk size `C` and `N` chunks:

- Chunk 1: `[0-Cs]`
- Chunk 2: `[C-2Cs]`
- ...
- Chunk N: `[(N-1)C-NCs]`

Use clean numeric notation matching the user's timing.

When exact total duration is shorter than the final full chunk boundary, write the prompt to the requested total duration and recommend Continuum `exact_total_duration` rather than pretending the model intrinsically samples a partial final chunk.

## Per-section content

Each section should include only the information needed for that interval:

1. inherited start state for Chunk 2+
2. movement phrase
3. transition and travel
4. camera behavior
5. boundary state or ending intent

Avoid repeating the complete global identity description in every section. Repetition can consume prompt attention without improving continuity.

## Continuity language

Useful semantic patterns:

- continue directly from the preceding landing
- preserve the current supporting leg
- carry the remaining clockwise momentum forward
- continue the same camera arc
- maintain the low body level through the first beat of the new phrase
- decelerate before reversing direction
- let the raised arm fall through the existing arc into the next initiation

Do not mechanically insert all of these.

## Continuum Settings output

Default minimal block:

```text
chunks: 6
chunk_seconds: 10
Prompt Format: Auto (Timeline)
continuity: Balanced - 22 frames
audio_continuity: On
```

Rules:

- Do not overwrite a user-specified sampler continuity profile.
- Distinguish prompt `continuity strength` from sampler `continuity`.
- If audio should remain continuous across chunks, recommend `audio_continuity: On`.
- Mention `exact_total_duration` only when relevant.
- Do not add accelerator recommendations unless the user asks.

## Fixed/List avoidance

For this skill's long dance output, prefer Timeline rather than Fixed.

List format can work but provides weaker explicit temporal planning for a choreography arc. Use List only if the user explicitly requests it.

## Prompt-only mode

When the user asks for prompt only:

- omit Continuum Settings
- omit explanations
- output only the Timeline prompt
