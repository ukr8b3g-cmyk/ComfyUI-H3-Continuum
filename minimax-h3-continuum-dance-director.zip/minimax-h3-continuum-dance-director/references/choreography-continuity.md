# Choreography Continuity

## Goal

Make a long routine feel like one uninterrupted performance rather than independent clips.

## Global Dance Spine

Before chunk writing, establish a full-sequence arc:

1. opening stance and first initiation
2. early vocabulary and groove
3. directional development
4. level or energy change
5. major phrase / climax
6. recovery or redirection
7. ending or loop return

Do not make every chunk climax independently.

## Motion State

Track the following at each boundary when relevant:

- support foot / support leg
- free-leg position
- center of mass
- hip orientation
- torso orientation
- shoulder line
- arm line
- hand direction
- head and gaze
- body level: standing / crouched / kneeling / floor
- travel direction
- angular momentum
- linear momentum
- recent landing quality
- camera side and motion

Not every field must be verbalized every time. Select the smallest set that uniquely constrains the handoff.

## Handoff grammar

A reliable boundary has three stages:

1. **Landing** — where the previous phrase physically arrives
2. **Carry** — what momentum, tension, weight, or trajectory remains
3. **Initiation** — how that inherited state causes the next phrase

Example concept:

- lands into the right leg
- torso remains wound left with clockwise rotation still decaying
- the stored rotation releases into a left-arm sweep and traveling pivot

Avoid:

- finishes a spin
- next she starts another dance move

## No-reset rule

Chunk 2+ must not default to:

- neutral standing pose
- centered front-facing pose
- symmetrical arms
- newly reset camera
- unexplained feet-together stance

unless Chunk N-1 deliberately ended there.

## Movement completion

Prefer fully expressed actions:

- show the weight transfer before the kick
- show the landing after the jump
- show compression before an explosive extension
- show deceleration before a direction reversal
- show hand/arm pathways rather than teleporting limb positions

## Rotations

Use rotations as purposeful transitions, not filler.

When a spin crosses a chunk boundary:

- state which foot or axis supports the rotation
- preserve rotation direction
- preserve torso winding
- continue camera orbit direction when useful
- resolve naturally before initiating an opposite-direction turn

## Traveling phrases

Maintain screen-space and stage-space logic.

If the dancer travels camera-right at the end of one chunk, the next chunk should not silently restart at center. Continue the travel, decelerate into a new pathway, or deliberately arc back.

## Floorwork

When ending a chunk low:

- retain the low level in the next opening
- identify knee/hip/hand support if needed
- rise through a physically readable transfer rather than popping upright

## Energy continuity

Each chunk should have a local role in the global routine:

- establish
- build
- redirect
- intensify
- suspend
- climax
- resolve

Use contrast intentionally. Continuity does not mean constant intensity.
