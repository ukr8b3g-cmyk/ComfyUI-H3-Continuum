# Selection Options

Use one compact selection message only when required information is missing.

Do not force the wizard when the user already supplied sufficient values.

## Field order

1. Dance Style
2. Total Duration
3. Chunk Duration
4. Performance Tone
5. Camera
6. Audio
7. Ending
8. Continuity Strength

Accept English keys, natural-language labels, option numbers, or `custom:<text>`.

## 1. Dance Style

- `auto`
- `hip_hop`
- `popping`
- `locking`
- `urban`
- `jazz`
- `contemporary`
- `ballet`
- `chinese_classical`
- `latin`
- `kpop`
- `sensual_flow`
- `house`
- `waacking`
- `voguing`
- `custom:<text>`

## 2. Total Duration

Common choices:

- `10s`
- `15s`
- `20s`
- `30s`
- `40s`
- `60s`
- `90s`
- `custom:<duration>`

Keep within the configured Continuum chunk count and the user's actual workflow limits. Do not claim a duration is locally validated unless the user provided that validation.

## 3. Chunk Duration

- `5s` — conservative starting point
- `6s`
- `10s`
- `15s`
- `custom:<seconds>`

Prefer the user's existing Continuum settings when known.

## 4. Performance Tone

- `auto`
- `powerful`
- `cool`
- `elegant`
- `playful`
- `dreamlike`
- `cinematic`
- `sensual`
- `aggressive`
- `minimal`
- `custom:<text>`

## 5. Camera

- `dance_follow` — dynamic but readable body-following camera
- `cinematic`
- `full_body_priority`
- `close_expression`
- `one_take`
- `orbit`
- `impact`
- `mostly_static`
- `custom:<text>`

## 6. Audio

- `no_audio_reference`
- `preserve_reference_audio`
- `dance_to_reference_audio`
- `dance_and_lipsync`
- `ambient_only`
- `custom:<text>`

If audio is unavailable for inspection, never invent exact timing details.

## 7. Ending

- `resolved_pose`
- `hero_pose`
- `impact_freeze`
- `gaze_finish`
- `soft_release`
- `closeup_finish`
- `loop_handoff`
- `continue_beyond_end`
- `custom:<text>`

For `loop_handoff`, make the final physical state geometrically and dynamically compatible with the opening state. Do not simply repeat the first pose.

## 8. Continuity Strength

- `light` — preserve identity and broad trajectory; allow looser pose evolution
- `natural` — default; inherit supporting leg, orientation, momentum, gaze, and camera direction when important
- `strong` — explicitly preserve more boundary mechanics; use for complex traveling or rotational phrases
- `custom:<text>`

This setting controls prompt detail, not the Continuum sampler's `continuity` profile. Keep the two concepts distinct.
