# Quality Guardrails

## Identity

Preserve the same primary dancer.

Do not introduce:

- clones
- extra limbs
- independent mirror duplicates
- costume swaps
- unexplained hairstyle changes
- face changes

## Anatomy

Prefer physically interpretable transitions.

Avoid combining too many simultaneous constraints such as:

- large jump
- extreme backbend
- rapid spin
- close-up
- floor contact
- prop exchange

inside the same short movement phrase.

## Prompt density

Short chunks need concise instructions.

If a section becomes a dense paragraph of unrelated movements, reduce the movement count rather than compressing the wording further.

## Scene stability

Do not use a new scene description in every chunk unless the user explicitly wants a location transition.

If a scene changes, make the transition choreographic and cinematic, not an unexplained reset.

## Camera-axis stability

Do not randomly flip left/right orientation across a boundary.

When crossing the camera axis intentionally, describe the camera path that performs the crossing.

## Ending

### Resolved pose
Decelerate into a stable final line and allow a brief readable hold.

### Impact freeze
Build a clear final accent, stop with physically plausible weight support, and avoid turning the freeze into an anatomy-breaking extreme pose.

### Soft release
Let energy dissipate through breath, shoulders, hands, or gaze.

### Loop handoff
Return toward an opening-compatible orientation, weight state, camera position, and momentum direction. Avoid a visible "teleport" back to the first pose.

### Continue beyond end
End with deliberately unresolved motion that suggests the routine continues after the generated sequence.

## No false quality claims

Prompt design can improve semantic continuity but cannot guarantee:

- seam-free pixels
- zero identity drift
- zero contrast/saturation drift
- perfect latent trajectory
- exact beat synchronization

Do not describe this skill as a technical fix for Continuum rendering/sampling problems.
