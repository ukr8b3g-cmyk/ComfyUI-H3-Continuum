# Notice

This package is an independent prompt-skill design for ComfyUI-H3-Continuum.

It was informed by public documentation and concepts from:

- `lj350201364/MiniMaxH3_Single_Dancer_Prompt_Skill`
- `ukr8b3g-cmyk/ComfyUI-H3-Continuum`
- `ukr8b3g-cmyk/write-h3-motion-prompts-skills`

The package does not copy or redistribute source files from the referenced Single-Dancer repository. The choreography, Continuum integration, reference documents, examples, and validation script in this package are newly written for this adaptation.

MiniMax, ComfyUI, OpenAI, Codex, Claude, and related names belong to their respective owners. This is not an official MiniMax or ComfyUI project.
