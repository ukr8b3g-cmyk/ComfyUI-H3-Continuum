---
name: write-continuum-h3-prompts
description: Write, adapt, or diagnose MiniMax H3 Continuum Sequence Prompts with Fixed, List, or Timeline chunk routing, long-form continuity, image and audio references, and append-only prompt extensions. Use for Continuum prompt authoring, not runtime repair or video generation.
---

# Write Continuum H3 Prompts

Produce copy-ready Sequence Prompt text, normally in English. Preserve supplied dialogue, lyrics, names and visible text verbatim unless the user requests a change. This is an independent Continuum adaptation, not an official MiniMax skill or a new model API.

## Workflow

1. Establish the actual generation mode, Chunks, Seconds per Chunk, enabled inputs and creative intent. Reuse known settings. Ask only when missing information materially affects routing; otherwise provide untimed Fixed prose without inventing runtime values.
2. Read [Continuum contract](references/continuum-contract.md) when selecting or repairing routing. It defines the version-pinned parser behavior. Keep model-facing shots separate from logical chunks.
3. For image modes, reference assets, dialogue or music, read [H3 and audio](references/h3-and-audio.md). Do not assume a numbered UI slot is the same as a model presentation label.
4. For complex, multi-shot, multi-reference or dialogue-heavy prompts, read [H3 prompt quality](references/prompt-quality.md). Apply its model-facing rules without confusing `[Shot N]` with Continuum `[Chunk N]` routing.
5. For multiple chunks, no-cut video or extending saved work, read [Continuity](references/continuity.md). For examples, consult [Examples](references/examples.md); durations there are examples, not defaults.
6. Choose the simplest format that preserves intent: Fixed for an ongoing state without distinct dialogue progression; Timeline with standalone numbered chunk headers for staged progression; time ranges for explicitly timed plans aligned to runtime boundaries; List to preserve a requested or existing list.
7. Write concrete current states and next actions. Keep identity, movement direction, camera, speaker mapping and relevant object states consistent. Do not invent observations of unseen images or generated frames.
8. Check header placement, coverage, nominal duration, reference mapping, preserved text and boundary handoffs. For complex prompts also check speaker ownership, action sequencing, camera perspective and unnecessary repeated appearance constraints. For extension, compare old text and common preamble without rewriting them.

## Output

Return a short settings note outside one copy-ready Sequence Prompt code block. Include Prompt Format, Chunks and Seconds per Chunk only when known or explicitly proposed. If prompt-only was requested, omit the note. Exclude citations, validation commentary and runtime metadata from the prompt block.

Do not automatically generate videos, modify workflows, install nodes or change settings. Do not promise perfect seams, identity, lip sync or correction of cumulative quality drift. A parsing rule is not a quality guarantee. Use the source baseline in the contract; if a supplied version differs, verify the relevant rules or disclose the mismatch rather than treating this document as universally current.
